CREATE DATABASE SchoolDB;
USE SchoolDB;
CREATE TABLE Students (
    StudentID INT PRIMARY KEY AUTO_INCREMENT,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    DOB DATE,
    EnrollmentDate DATE
);
CREATE TABLE Courses (
    CourseID INT PRIMARY KEY AUTO_INCREMENT,
    CourseName VARCHAR(100),
    Credits INT
);
CREATE TABLE Enrollments (
	EnrollmentID 	INTEGER,
	StudentID	INTEGER,
	CourseID	INTEGER,
	Grade	TEXT,
	PRIMARY KEY(EnrollmentID),
	FOREIGN KEY(CourseID) REFERENCES Courses(CourseID),
	FOREIGN KEY(StudentID) REFERENCES Students(StudentID)
);
INSERT INTO Students (FirstName, LastName, DOB, EnrollmentDate)
VALUES ('Bontle', 'Chaphole', '1999-10-18', '2021-01-10'),
('Bahle', 'Bolilitye', '2003-08-04', '2021-04-10'),
('Katlego', 'Litlake', '2000-02-25', '2021-06-10'),
('Momelezi', 'Qasana', '1997-02-25', '2021-03-20'),
('Akhona', 'Rilityana', '2002-07-19', '2021-05-22');
 
INSERT INTO Courses (courseID,CourseName, Credits)
VALUES (110, 'Data Analyst', '30'),
(120, 'Cybersecurity', '35'),
(130, 'Helpdesk', '20'),
(140, 'Web Development', '40'),
(150, 'Networking', '45');
INSERT INTO Enrollments (EnrollmentID, StudentID, CourseID, Grade)
VALUES (1, '1', '110' ,'A'),
(2, '2', '120' ,'A'),
(3, '3', '130' ,'D'),
(4, '4', '140' ,'D'),
(5, '5', '150' ,'B');
CREATE VIEW StudentGrades AS
SELECT 
    Students.StudentID,
    Students.FirstName,
    Students.LastName,
    Enrollments.CourseID,
    Enrollments.Grade
FROM 
    Students
JOIN 
    Enrollments ON Students.StudentID = Enrollments.StudentID;
DELIMITER $$
 
 
DELIMITER //
CREATE PROCEDURE GetStudentGrades(IN studentID INT)
BEGIN
    SELECT 
        s.FirstName,
        s.LastName,
        c.CourseName,
        e.Grade
    FROM Students s
    JOIN Enrollments e ON s.StudentID = e.StudentID
    JOIN Courses c ON e.CourseID = c.CourseID
    WHERE s.StudentID = studentID;
END //
DELIMITER ;
-- Add Enrollment
DELIMITER //
CREATE PROCEDURE AddEnrollment(IN studentID INT, IN courseID INT, IN grade CHAR(2))
BEGIN
    INSERT INTO Enrollments (StudentID, CourseID, Grade) VALUES (studentID, courseID, grade);
END //
DELIMITER ;
 
CREATE DATABASE SchoolDB;
USE SchoolDB;
CREATE TABLE Students (
    StudentID INT PRIMARY KEY AUTO_INCREMENT,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    DOB DATE,
    EnrollmentDate DATE
);
CREATE TABLE Courses (
    CourseID INT PRIMARY KEY AUTO_INCREMENT,
    CourseName VARCHAR(100),
    Credits INT
);
CREATE TABLE Enrollments (
	EnrollmentID 	INTEGER,
	StudentID	INTEGER,
	CourseID	INTEGER,
	Grade	TEXT,
	PRIMARY KEY(EnrollmentID),
	FOREIGN KEY(CourseID) REFERENCES Courses(CourseID),
	FOREIGN KEY(StudentID) REFERENCES Students(StudentID)
);
INSERT INTO Students (FirstName, LastName, DOB, EnrollmentDate)
VALUES ('Bontle', 'Chaphole', '1999-10-18', '2021-01-10'),
('Bahle', 'Bolilitye', '2003-08-04', '2021-04-10'),
('Katlego', 'Litlake', '2000-02-25', '2021-06-10'),
('Momelezi', 'Qasana', '1997-02-25', '2021-03-20'),
('Akhona', 'Rilityana', '2002-07-19', '2021-05-22');
 
INSERT INTO Courses (courseID,CourseName, Credits)
VALUES (110, 'Data Analyst', '30'),
(120, 'Cybersecurity', '35'),
(130, 'Helpdesk', '20'),
(140, 'Web Development', '40'),
(150, 'Networking', '45');
INSERT INTO Enrollments (EnrollmentID, StudentID, CourseID, Grade)
VALUES (1, '1', '110' ,'A'),
(2, '2', '120' ,'A'),
(3, '3', '130' ,'D'),
(4, '4', '140' ,'D'),
(5, '5', '150' ,'B');
CREATE VIEW StudentGrades AS
SELECT 
    Students.StudentID,
    Students.FirstName,
    Students.LastName,
    Enrollments.CourseID,
    Enrollments.Grade
FROM 
    Students
JOIN 
    Enrollments ON Students.StudentID = Enrollments.StudentID;
DELIMITER $$
 
 
DELIMITER //
CREATE PROCEDURE GetStudentGrades(IN studentID INT)
BEGIN
    SELECT 
        s.FirstName,
        s.LastName,
        c.CourseName,
        e.Grade
    FROM Students s
    JOIN Enrollments e ON s.StudentID = e.StudentID
    JOIN Courses c ON e.CourseID = c.CourseID
    WHERE s.StudentID = studentID;
END //
DELIMITER ;
-- Add Enrollment
DELIMITER //
CREATE PROCEDURE AddEnrollment(IN studentID INT, IN courseID INT, IN grade CHAR(2))
BEGIN
    INSERT INTO Enrollments (StudentID, CourseID, Grade) VALUES (studentID, courseID, grade);
END //
DELIMITER ;
 
select * from Students;
select * from Courses;
select * from Enrollments;
Select * from